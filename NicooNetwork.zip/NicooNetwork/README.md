# NicooNetwork

[![CI Status](https://img.shields.io/travis/504672006@qq.com/NicooNetwork.svg?style=flat)](https://travis-ci.org/504672006@qq.com/NicooNetwork)
[![Version](https://img.shields.io/cocoapods/v/NicooNetwork.svg?style=flat)](https://cocoapods.org/pods/NicooNetwork)
[![License](https://img.shields.io/cocoapods/l/NicooNetwork.svg?style=flat)](https://cocoapods.org/pods/NicooNetwork)
[![Platform](https://img.shields.io/cocoapods/p/NicooNetwork.svg?style=flat)](https://cocoapods.org/pods/NicooNetwork)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

NicooNetwork is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'NicooNetwork'
```

## Author

504672006@qq.com, yangxin@tzpt.com

## License

NicooNetwork is available under the MIT license. See the LICENSE file for more info.
